package principal;

import clases.VentanaJ;
import javax.swing.JFrame;

/**
 *
 *
 * @author Eduardo Martinez
 */

public class PrincipalJ {

    public static void main(String[] args) {
        VentanaJ ventana = new VentanaJ();//psvm + tab
    }
}
