
package clases;

/**
 *
 * @author Eduardo Martinez
 */
import java.applet.AudioClip;

public class SonidoJ {

    public AudioClip getAudio(String direccion) {
        return java.applet.Applet.newAudioClip(getClass().getResource(direccion));
    }
   
}
