
package clases;

/**
 *
 * @author Eduardo Martinez
 */
import javax.swing.*;

public class VentanaJ extends JFrame {//Extendemos la clase JFrame

    MesaJ Base;//Objeto del JPanel
    private final int Ancho = 800, Altura = 500;//Variables Constantes
    PelotaJ p = new PelotaJ();

    public VentanaJ() {//Constructor
        setTitle("Game Ping-Pong ");//Titulo De La Ventana
        setSize(Ancho, Altura);//Tamaño de la ventana
        setLocationRelativeTo(null);//Metodo para la Ubicacion  de la ventana en el centro
        setResizable(false);//Metodo para Impedir modificar el tamaño de la ventana grafica.
        Base = new MesaJ();//Creamos el objeto de la Base
        add(Base);//y Añadimos al JFrame
        setVisible(true);//Hace visible la ventana
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);// Termina todos los procesos y cierra el programa
        addKeyListener(new ETeclasJ());//Objeto para las pulsaciones de las teclas dadas
        new HiloJ(Base).start();//Iniamos el hilo
    }

}
