
package clases;

import java.awt.*;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.geom.Line2D;
import java.awt.geom.Rectangle2D;
import javax.swing.JPanel;

/**
 *
 * @author Eduardo Martinez
 */
public class MesaJ extends JPanel {

    RacketJ ra1 = new RacketJ(10, 200);
    RacketJ ra2 = new RacketJ(794 - 10 - RacketJ.Ancho, 200);
    PelotaJ p = new PelotaJ();

    public MesaJ() {//Constructor
        this.setBackground(Color.CYAN);//Fondo de Color con el metodo setBackground
    }

    @Override
    public void paintComponent(Graphics h) {//Metodo sobreescrito paintComponent que pertenece a la clase Padre
        super.paintComponent(h);//Se ejecute el metodo paintComponent de la clase padre
        //Convertimos el objeto Graphics en Graphics2D
        Graphics2D h2 = (Graphics2D) h;//Objeto 2d, es una clase hija de la clase Graphics
        h2.setPaint(Color.MAGENTA);//Color de los objetos dentro del JPanel (Pelota, Raqueta)
        Puntaje(h2);
        dibujar(h2);

    }

    private void dibujar(Graphics2D h) {//Dibujamos los objetos
        //LLeva un parametro de tipo Graphics2D con nombre "h" porque pertenece a la clase padre
        Line2D.Double linea = new Line2D.Double(getBounds().getCenterX(), 0, getBounds().getCenterX(), getBounds().getMaxY());
        h.draw(linea);//Se dibuja o muestra la linea
        
        //Dibujamos la figura con el metodo fill
        h.fill(ra1.getRaqueta());//Como parametro debemos amndarle como tamaño getRaqueta
        Actualizar();

        h.fill(ra2.getRaqueta());
        Actualizar();

        h.fill(p.getPelota());//Como parametro debemos amndarle como tamaño getPelota
        Actualizar();
    }

    //actualiza el estado (posicion) de las raquetas y pelota)
    private void Actualizar() {

        p.moverPelota(getBounds(), colision(ra1.getRaqueta()), colision(ra2.getRaqueta()));

        ra1.moverR1(getBounds());
        ra2.moverR2(getBounds());
    }

    //detecta si existe una colision entre la raqueta y la pelota
    private boolean colision(Rectangle2D r) {
        return p.getPelota().intersects(r);
    }

    private void Puntaje(Graphics2D h) {
        Graphics2D h1 = h, h2 = h;
        Font Puntuacion = new Font("Times New Roman", Font.BOLD, 40);
        h.setFont(Puntuacion);

        h1.drawString(Integer.toString(p.getScore1()), (float) getBounds().getCenterX() - 50, 30);
        h2.drawString(Integer.toString(p.getScore2()), (float) getBounds().getCenterX() + 25, 30);
        if (p.getScore1() == 3) {
            h.drawString("   GANÓ El JUGADOR 1", (float) getBounds().getCenterX() - 180, (float) getBounds().getCenterY() - 100);
            PelotaJ.GO = true;
        }
        
        if (p.getScore2() == 3) {
            h.drawString("   GANÓ EL JUGADOR 2", (float) getBounds().getCenterX() - 180, (float) getBounds().getCenterY() - 100);
            PelotaJ.GO = true;
        }
    }

}
