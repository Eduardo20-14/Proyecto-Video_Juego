
package clases;

import java.awt.Rectangle;
import java.awt.geom.Rectangle2D;

/**
 *
 * @author Eduardo Martinez
 */
public class RacketJ {

    private int a, b;//a = x, y  b = y
    static final int Ancho = 20, Altura = 50;

    public RacketJ(int x, int y) {
        this.a = x;
        this.b = y;
    }

    public Rectangle2D getRaqueta() {
        return new Rectangle2D.Double(a, b, Ancho, Altura);
    }

    public void moverR1(Rectangle limites) {
        if (ETeclasJ.w && b > limites.getMinY()) {
            b--;
        }
        if (ETeclasJ.s && b < limites.getMaxY()-Altura) {
            b++;
        }
    }

    public void moverR2(Rectangle limites) {
        if (ETeclasJ.up && b > limites.getMinY()) {
            b--;
        }
        if (ETeclasJ.down && b < limites.getMaxY()-Altura) {
            b++;
        }
    }
}
