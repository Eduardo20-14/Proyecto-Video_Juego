
package clases;

import clases.MesaJ;
import clases.PelotaJ;

/**
 *
 * @author Eduardo Martinez
 */
public class HiloJ extends Thread {

    private final MesaJ Base;//Objeto de la clase MesaJ

    public HiloJ(MesaJ Base) {//Constructor que lleva como`parametro un objeto de la clase MesaJ
        this.Base = Base;// Aqui lo instanciamos
    }

    @Override
    public void run() {
        while (!PelotaJ.GO) {
            Base.repaint();
            try {
                Thread.sleep(8);//Velocidad en la que se detiene el programa cada 8 milisegundo
            } catch (Exception ex) {
                System.out.println("Ocurrio Un Error En El Hilo: " + ex.getMessage());
            }
        }
    }
}
