
package clases;

import java.applet.AudioClip;
import java.awt.geom.Rectangle2D;

/**
 *
 * @author Eduardo Martinez
*/
public class PelotaJ {

    private static final int Ancho = 15, Altura = 15;//Variables constantes
    private double a = 0;//La Variable a = x
    private static double b = 0;//La Variable b = y
    private double da = 1, db = 1;//Variables el cual se iran sumando con a y b
    private Integer Puntuacion1 = 0, Puntuacion2 = 0;
    public static boolean GO = false;//GO = GAME OVER
    
     SonidoJ audio = new SonidoJ();
     AudioClip rebote_1=audio.getAudio("/clases/rebote_pelota1.wav");
     AudioClip rebote_2=audio.getAudio("/clases/rebote_pelota2.wav");
    
    //retorna la pelota (Rectangle2D implementa la interface Pelota)
    public Rectangle2D getPelota() {
        return new Rectangle2D.Double(a, b, Ancho, Altura);
    }

    public void moverPelota(Rectangle2D limites, boolean colisionR1, boolean colisionR2) {
        //Le estamos dando movimiento a la pelota
        a += da;//A se suma a DA
        b += db;//B se suma a DB

        if (colisionR1) {//Debe existir una colision entre la Raqueta y la Pelota
            da = -da;////Para que cuando llegue al limite del JPanel rebote la pelota
            a = 20;
            rebote_1.play();//Reproduce el sonido si es verdadero la colision
        }
        
        if (colisionR2) {
            da = -da;//Para que cuando llegue al limite del JPanel rebote la pelota
            a = 755;
            rebote_1.play();//Reproduce el sonido si es verdadero la colision
        }

        //EN X
        if (a < limites.getMinX()) {//Para que al pasar la pelota le de el punto al otro jugador
            Puntuacion2++; //el puntaje del jugador2 aumenta en uno
           
            a = limites.getCenterX();
            b = limites.getCenterY();
            da = -da;
        }

        if (a + Ancho >= limites.getMaxX()) {//Para que al pasar la pelota le de el punto al otro jugador
            Puntuacion1++; //el puntaje del jugador1 aumenta en uno
            
            a = limites.getCenterX();
            b = limites.getCenterY();
            da = -da;
        }

        //EN Y
        if (b < limites.getMinY()) {

            b = limites.getMinY();

            db = -db;
            rebote_2.play();//Reproduce el sonido si es verdadero la colision
        }

        if (b + Altura >= limites.getMaxY()) {//Para que rebote al llegar al extremo en Y

            b = limites.getMaxY() - Altura;

            db = -db;
            rebote_2.play();//Reproduce el sonido si es verdadero la colision
        }

    }

    public int getScore1() {
        return Puntuacion1;
    }

    public int getScore2() {
        return Puntuacion2;
    }

    
    
}
